#!/bin/bash
cd "$(dirname "$0")"
node index.js